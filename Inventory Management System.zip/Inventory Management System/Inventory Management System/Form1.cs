﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Collections;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace Inventory_Management_System
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        [DllImport("Library.dll", CallingConvention = CallingConvention.Cdecl)]
        static extern int Calculate_Price_x_NoOfItems(int Price, int NoOfItems);

        [DllImport(@"D:\Visual Studio 2012\Projects\Library\Debug\Library.dll", CallingConvention = CallingConvention.StdCall)]
        static extern void Write(StringBuilder barcode, StringBuilder xyz);

        [DllImport(@"D:\Visual Studio 2012\Projects\Library\Debug\Library.dll", CallingConvention = CallingConvention.StdCall)]
        static extern void Read(StringBuilder barcode, StringBuilder xyz);

        [DllImport(@"D:\Visual Studio 2012\Projects\Library\Debug\Library.dll", CallingConvention = CallingConvention.StdCall)]
        static extern void Append(StringBuilder barcode, StringBuilder xyz);


        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (comboBox1.SelectedItem != null && textBox1 != null && textBox2 != null)
                {
                    int a = int.Parse(textBox1.Text);
                    int b = int.Parse(textBox2.Text);
                    int result = Calculate_Price_x_NoOfItems(a, b);
                    string[] row = new string[] { comboBox1.Text, textBox1.Text, textBox2.Text, result.ToString() };
                    dataGridView1.Rows.Add(row);
                    textBox1.Text = string.Empty;
                    textBox2.Text = "";
                    comboBox1.Text = "";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Mandatory Fields Empty!!");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Enabled = false;
            textBox3.Text = "00000593";
            textBox4.Text = DateTime.Now.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Library Library = new Library(textBox6.Text);
            Library.Write(textBox5.Text);
            comboBox1.Items.Add(textBox6.Text);
            MessageBox.Show("New Item Added to the Inventory!");
            textBox6.Text = "";
            textBox5.Text = "";
        }
        int rst;
        int temp;
        int total;
        private void button4_Click(object sender, EventArgs e)
        {
            temp = 0;
            for (int i = 0; i <= dataGridView1.RowCount-2; i++)
            {
                rst = int.Parse(dataGridView1.Rows[i].Cells[3].Value.ToString());
                temp = temp + rst;

            }
            richTextBox1.Text = temp.ToString();
        }

        private void comboBox1_TextChanged(object sender, EventArgs e)
        {
                    Library Library = new Library(this.comboBox1.GetItemText(this.comboBox1.SelectedItem));
                    Library.Read(textBox1);
        }

        

        



    }
}
