﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory_Management_System
{
    class Library
    {
        StreamWriter sw;
        string filename;

        #region
        //public Library()
        //{
        //    filename = "BarCodes.txt";
        //    sw = new StreamWriter(filename);

        //}
        public Library(string path)
        {
            filename = path + ".txt";
            sw = new StreamWriter(filename,true);
        }
        #endregion


        //public void write(string[] arrayMessage)
        //{
        //    for (int i = 0; i < arrayMessage.Length; i++)
        //    {
        //        sw.WriteLine(arrayMessage[i]);
        //    }
        //    sw.Close();
        //}


        public void Write(string txtbox)
        {
            sw.WriteLine(txtbox);
            sw.Close();
        }


        public string read()
        {
            string[] messageArray = File.ReadAllLines(filename+".txt");

            string save = "";
            int i = 0;
        x:
            if (i < messageArray.Length)
            {
                save += messageArray[i].ToString() + "\n";
                i++;
                goto x;
            }
            return save;
        }

        public string Read(TextBox t)
        {
            sw.Close();
            string[] messageArray = File.ReadAllLines(filename);
            //sw.Close();
            for (int i = 0; i < messageArray.Length; i++)
            {
                t.Text = messageArray[i];
            }
            //foreach (string s in messageArray)
            //{
            //    t.Text += s;
            //}
            return "";
        }


        public string reaaaad()
        {
            sw.Close();
            string[] messageArray = File.ReadAllLines(filename);

            string save = "";
            int a = 0;
        x:
            if (a < messageArray.Length)
            {
                save += messageArray[a].ToString() + "\n";
                a++;
                goto x;
            }
        sw.Close();
            return save;
        }

        public string search(string search)
        {
            string result;
            int index = 0;
            for (int i = 0; i < filename.Length; i++)
            {
                if (search == filename[i].ToString())
                {
                     index = i;
                    result = filename[i + 1].ToString();
                    return result;
                }
            }
            return "";
        }
    }
}
